create
    definer = root@localhost procedure Busqueda_por_Tarea(IN Categoria int)
BEGIN
    SELECT c.Nombre_C AS Categoria, 
           CONCAT(e.Nombre, ' ', e.Apellido) AS Nombre_Empleado, 
           COUNT(t.id_Tarea) AS Cantidad_de_tareas_realizadas
    FROM CATEGORIA c 
    INNER JOIN TAREA t ON c.id_Categoria = t.id_categoria 
    INNER JOIN EMPLEADO e ON t.id_empleado = e.id_Empleado 
    WHERE Categoria = c.id_Categoria
    GROUP BY c.Nombre_C, e.Nombre, e.Apellido;
END;


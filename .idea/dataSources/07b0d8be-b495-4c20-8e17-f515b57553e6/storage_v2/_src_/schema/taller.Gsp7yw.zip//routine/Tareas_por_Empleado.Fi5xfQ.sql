create
    definer = root@localhost procedure Tareas_por_Empleado(IN id_E int, IN Fecha_uno datetime, IN Fecha_dos datetime)
BEGIN
    SELECT e.id_Empleado, CONCAT(e.Nombre, ' ', e.Apellido) AS Nombre_Empleado, t.Fecha, t.Descripcion AS Tarea 
    FROM EMPLEADO e 
    INNER JOIN TAREA t ON e.id_Empleado = t.id_empleado 
    WHERE t.Fecha BETWEEN Fecha_uno AND Fecha_dos;
END;

